
package org.jfree.chart.urls;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.jfree.chart.api.PublicCloneable;

import org.jfree.data.category.CategoryDataset;


public class CustomCategoryURLGenerator implements CategoryURLGenerator,
        Cloneable, PublicCloneable, Serializable {

    
    private List<List<String>> urlSeries = new ArrayList<>();

    
    public CustomCategoryURLGenerator() {
        super();
    }

    
    public int getListCount() {
        return this.urlSeries.size();
    }

    
    public int getURLCount(int list) {
        int result = 0;
        List<String> urls = this.urlSeries.get(list);
        if (urls != null) {
            result = urls.size();
        }
        return result;
    }

    
    public String getURL(int series, int item) {
        String result = null;
        if (series < getListCount()) {
            List<String> urls = this.urlSeries.get(series);
            if (urls != null) {
                if (item < urls.size()) {
                    result = urls.get(item);
                }
            }
        }
        return result;
    }

    
    @Override
    public String generateURL(CategoryDataset<?, ?> dataset, int series, int item) {
        return getURL(series, item);
    }

    
    public void addURLSeries(List<String> urls) {
        List<String> listToAdd = null;
        if (urls != null) {
            listToAdd = new ArrayList<>(urls);
        }
        this.urlSeries.add(listToAdd);
    }

    
    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof CustomCategoryURLGenerator)) {
            return false;
        }
        CustomCategoryURLGenerator generator = (CustomCategoryURLGenerator) obj;
        int listCount = getListCount();
        if (listCount != generator.getListCount()) {
            return false;
        }

        for (int series = 0; series < listCount; series++) {
            int urlCount = getURLCount(series);
            if (urlCount != generator.getURLCount(series)) {
                return false;
            }

            for (int item = 0; item < urlCount; item++) {
                String u1 = getURL(series, item);
                String u2 = generator.getURL(series, item);
                if (u1 != null) {
                    if (!u1.equals(u2)) {
                        return false;
                    }
                } else {
                    if (u2 != null) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    
    @Override
    public Object clone() throws CloneNotSupportedException {
        CustomCategoryURLGenerator clone
                = (CustomCategoryURLGenerator) super.clone();
        clone.urlSeries = new ArrayList<>(this.urlSeries);
        return clone;
    }

}