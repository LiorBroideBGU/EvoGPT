

package com.google.gson.internal;


public final class JavaVersion {
  // Oracle defines naming conventions at
  // http://www.oracle.com/technetwork/java/javase/versioning-naming-139433.html
  // However, many alternate implementations differ. For example, Debian used 9-debian as the
  // version string

  private static final int majorJavaVersion = determineMajorJavaVersion();

  private static int determineMajorJavaVersion() {
    String javaVersion = System.getProperty("java.version");
    return parseMajorJavaVersion(javaVersion);
  }

  // Visible for testing only
  static int parseMajorJavaVersion(String javaVersion) {
    int version = parseDotted(javaVersion);
    if (version == -1) {
      version = extractBeginningInt(javaVersion);
    }
    if (version == -1) {
      return 6; // Choose minimum supported JDK version as default
    }
    return version;
  }

  // Parses both legacy 1.8 style and newer 9.0.4 style
  private static int parseDotted(String javaVersion) {
    try {
      String[] parts = javaVersion.split("[._]", 3);
      int firstVer = Integer.parseInt(parts[0]);
      if (firstVer == 1 && parts.length > 1) {
        return Integer.parseInt(parts[1]);
      } else {
        return firstVer;
      }
    } catch (NumberFormatException e) {
      return -1;
    }
  }

  private static int extractBeginningInt(String javaVersion) {
    try {
      StringBuilder num = new StringBuilder();
      for (int i = 0; i < javaVersion.length(); ++i) {
        char c = javaVersion.charAt(i);
        if (Character.isDigit(c)) {
          num.append(c);
        } else {
          break;
        }
      }
      return Integer.parseInt(num.toString());
    } catch (NumberFormatException e) {
      return -1;
    }
  }

  
  public static int getMajorJavaVersion() {
    return majorJavaVersion;
  }

  
  public static boolean isJava9OrLater() {
    return majorJavaVersion >= 9;
  }

  private JavaVersion() {}
}
